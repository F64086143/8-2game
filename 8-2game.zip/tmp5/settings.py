import pygame
import os

# screen size
WIN_WIDTH = 1024
WIN_HEIGHT = 600
# frame rate
FPS = 60
# color
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
PURPLE = (147, 0, 147)
# enemy path
PATH = [(1010, 475), (994, 500), (971, 525), (952, 541), (932, 553), (902, 550), (879, 532),
        (860, 511), (833, 488), (805, 483), (777, 467), (767, 437), (743, 416), (715, 407),
        (702, 421), (697, 461), (683, 487), (662, 504), (636, 519), (608, 531), (588, 506),
        (566, 484), (532, 457), (518, 471), (495, 504), (464, 520), (439, 484), (425, 456),
        (384, 456), (368, 468), (347, 480), (324, 498), (284, 516), (255, 491), (235, 459), (211, 468)]
# base
BASE = pygame.Rect(120, 250, 230, 300)

# image
BACKGROUND_IMAGE = pygame.image.load(os.path.join("images", "back.png"))
HP_GRAY_IMAGE = pygame.transform.scale(pygame.image.load("images/heart 2.png"), (28, 28))
HP_IMAGE = pygame.transform.scale(pygame.image.load("images/heart.png"), (28, 28))
BOY_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "boy.png")), (300, 300))
TRYAGAIN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "tryagain.png")), (200, 70))
MENU_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "list.png")), (420, 250))
muse_button_image = pygame.transform.scale(pygame.image.load("images/mute.png"), (80, 80))
music_button_image = pygame.transform.scale(pygame.image.load("images/soundon.png"), (80, 80))


