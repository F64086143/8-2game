import pygame
from settings import WIN_WIDTH, WIN_HEIGHT, HP_IMAGE, HP_GRAY_IMAGE, BACKGROUND_IMAGE,BOY_IMAGE,TRYAGAIN_IMAGE,muse_button_image,music_button_image,MENU_IMAGE
from color_settings import *
import math


class GameView:
    def __init__(self):
        self.win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        self.font = pygame.font.SysFont("comicsans", 30)

    def draw_bg(self):
        self.win.blit(BACKGROUND_IMAGE, (0, 0))
        self.win.blit(BOY_IMAGE,(120,250))
        self.win.blit(muse_button_image, (240, 10))
        self.win.blit(music_button_image, (150, 10))

    def draw_time(self):
        seconds = (100000 - pygame.time.get_ticks()) / 1000
        mins = str(math.floor(seconds) // 60).zfill(2)
        secs = str(math.floor(seconds) % 60).zfill(2)
        self.font = pygame.font.SysFont(None, 40)
        text_surface = self.font.render(mins + ':' + secs, True, (0, 0, 0))
        self.win.blit(text_surface, (700, 20))  # 印出時間
        if seconds < 0:
            pygame.quit()
            exit()

    def draw_enemies(self, enemies):
        for en in enemies.get():
            self.win.blit(en.image, en.rect)
            # draw health bar
            bar_width = en.rect.w * (en.health / en.max_health)
            max_bar_width = en.rect.w
            bar_height = 5
            pygame.draw.rect(self.win, RED, [en.rect.x, en.rect.y - 10, max_bar_width, bar_height])
            pygame.draw.rect(self.win, GREEN, [en.rect.x, en.rect.y - 10, bar_width, bar_height])


    def draw_menu(self, menu):
        self.win.blit(MENU_IMAGE, (320, 85))
        text = self.font.render(f"$150", True, (0, 0, 0))
        self.win.blit(text, (340, 150))
        text = self.font.render(f"$350", True, (0, 0, 0))
        self.win.blit(text, (480, 150))
        text = self.font.render(f"$600", True, (0, 0, 0))
        self.win.blit(text, (660, 150))

        for btn in menu.buttons:
            self.win.blit(btn.image, btn.rect)


    # 籃子按鈕
    def draw_plots(self, plots):
        for pt in plots:
            self.win.blit(pt.image, pt.rect)

    def draw_money(self, money: int):
        """ (Q2.1)render the money"""
        text = self.font.render(f"Money: {money}", True, (0, 0, 0))
        self.win.blit(text, (5, 15))


    def draw_hp(self, lives):
        # draw_lives
        hp_rect = HP_IMAGE.get_rect()
        for i in range(10):
            self.win.blit(HP_GRAY_IMAGE, (WIN_WIDTH // 2 - hp_rect.w * (2.5 - i % 5), hp_rect.h * (i // 5)))
        for i in range(lives):
            self.win.blit(HP_IMAGE, (WIN_WIDTH // 2 - hp_rect.w * (2.5 - i % 5), hp_rect.h * (i // 5)))
        if int(lives) <= 0:
            self.win.blit(TRYAGAIN_IMAGE, (400, 250))








