import pygame
import os

pygame.init()
MENU_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "list.png")), (400, 300))

# 籃子
MASK_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "mask.png")), (100, 100))
HAZMAT_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "hazmat.png")), (100, 100))
TESTING_BTN_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "testing.png")), (100, 100))

# 靜音
muse_button_image = pygame.transform.scale(pygame.image.load("images/muse.png"), (80, 80))
music_button_image = pygame.transform.scale(pygame.image.load("images/sound.png"), (80, 80))
continue_button_image = pygame.transform.scale(pygame.image.load("images/continue.png"), (80, 80))
pause_button_image = pygame.transform.scale(pygame.image.load("images/pause.png"), (80, 80))

TRYAGAIN_IMAGE = pygame.transform.scale(pygame.image.load("images/tryagain.png"), (200, 70))

class Button:
    def __init__(self, image, name: str, x: int, y: int):
        self.image = image
        self.name = name
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        return True if self.rect.collidepoint(x, y) else False

    @property
    def response(self):
        return self.name

# try按鈕
class Tryagain:
    def __init__(self, x, y):
        self.image = TRYAGAIN_IMAGE
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self._buttons = [Button(TRYAGAIN_IMAGE, "tryagain", self.rect.centerx, self.rect.centery)]

    def clicked(self, x, y):
        return True if self.rect.collidepoint(x, y) else False


class Menu:
    def __init__(self, x: int, y: int):
        self.image = MENU_IMAGE
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self._buttons = []

    @property
    def buttons(self):
        return self._buttons

# 籃子清單
class BuildMenu(Menu):
    def __init__(self, x, y):
        super().__init__(x, y)
        self._buttons = [Button(MASK_BTN_IMAGE, "mask", self.rect.centerx +300, self.rect.centery - 300),
                         Button(HAZMAT_BTN_IMAGE, "hazmat", self.rect.centerx +450, self.rect.centery - 300),
                         Button(TESTING_BTN_IMAGE, "testing", self.rect.centerx +600, self.rect.centery - 300),
                         ]

# 靜音清單
class MainMenu:
    def __init__(self):
        self._buttons = [Button(music_button_image, "music", 150, 30),
                         Button(muse_button_image, "mute", 240, 30),
                         Button(continue_button_image, "continue", 905, 40),
                         Button(pause_button_image, "pause", 990, 40)]

    @property
    def buttons(self):
        return self._buttons







