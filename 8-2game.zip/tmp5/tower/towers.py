import os
import pygame

PLOT_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join("images", "basket.png")), (90, 90))

# 籃子
class Vacancy:
    def __init__(self, x, y):
        self.image = PLOT_IMAGE
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x: int, y: int) -> bool:
        return True if self.rect.collidepoint(x, y) else False





